export default function OtherAttractions() {
  return (
    <div className="OtherAttractions">
      <h2>Інші пам'ятки</h2>
      <p>Замок, музеї, старовинні церкви та мальовничі парки.</p>
            <img src="https://f.rivne.travel/city/140/7-Cbp.jpg" alt="Острог"  />
            <img src="https://ukrainetrek.com/blog/wp-content/uploads/2019/10/ostroh-castle-rivne-oblast-ukraine-2.jpg" alt="Острог"  />
            <img src="https://th.bing.com/th/id/R.e2b0ea8b4ade94082093fcedc91aefed?rik=aLL%2fxkzhIt0T3g&riu=http%3a%2f%2fukrainaincognita.com%2fwp-content%2fuploads%2ffiles%2fostrog14_kost5.jpg&ehk=DL92PMLzVZ7ivHFa0e3jK%2bkeTG1x8BaYtH1e0VPMtFo%3d&risl=&pid=ImgRaw&r=0" alt="Острог"  />

    </div>
  );
}