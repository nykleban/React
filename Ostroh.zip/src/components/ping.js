function Ping() {
  return <div>OK</div>;
}


export default Ping;